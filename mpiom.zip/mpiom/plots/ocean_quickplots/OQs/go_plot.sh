#!/bin/bash -ex

YEAR_START=2100
YEAR_END=2101
INTERVAL=2

export EXPID=hel17115-RSF

export DATADIR=/mnt/lustre01/work/mh0033/m211054/projects/cmip6/mpiesm-1.2.01-release/experiments/${EXPID}/outdata/mpiom

export CDO='cdo -s -P 4'
export CHUNK=1
export GRID=TP04
export LEV=L40
export POOL=/pool/data/MPIOM/input/r0008
OQSDIR=$(pwd)  #add here path to the OQs scripts 

# Create plots
YEAR=$YEAR_START
while [ $YEAR -le $(( YEAR_END - INTERVAL + 1)) ]
do

    Y1=$YEAR Y2=$(( YEAR + INTERVAL - 1 )) ${OQSDIR}/plot_mpiom.sh
    YEAR=$(( YEAR + INTERVAL ))
    
done

exit
