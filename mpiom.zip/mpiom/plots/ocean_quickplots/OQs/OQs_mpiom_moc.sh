#! /usr/bin/env bash
set -e

set -x # DEBUG

PROGRAM=$(basename $0)

TMP_DIR=${PROGRAM}_$Y1-$Y2
[ -e $TMP_DIR ] && rm -rf $TMP_DIR
mkdir -p $TMP_DIR
cd $TMP_DIR

CATFILE=moc.nc

CODE='100,101,102'

for YEAR in $(seq $Y1 $CHUNK $Y2) 
do
    INFILE=$(printf $DATADIR/${EXPID}_mpiom_data_moc_mm_%04.0f0101_%04.0f1231.nc $YEAR $((YEAR + CHUNK - 1)))

    if [ -e $INFILE ]
    then
        $CDO cat -timmean -selcode,$CODE $INFILE $CATFILE
    else
        echo Warning ! $INFILE is missing, skipping to next file ...
    fi
done

$CDO sinfo $CATFILE # DEBUG
inbase=$(printf ${EXPID}_mpiom_moc_%04.0f0101_%04.0f1231 $Y1 $Y2)
infile=$inbase.nc
outfile=$inbase.pdf
$CDO timmean $CATFILE $infile

$CDO -f nc -setunit,"Sv" -mulc,1.025e-9 -selcode,100 $infile glo_moc.$infile
ncrename -d depth_2,depth -v depth_2,depth  glo_moc.$infile
$BINDIR/plotsec_ncl --rstring=glo --code=100 --min=-24 --max=24 --inc=3 --pal=BlueWhiteOrangeRed glo_moc.$infile

$CDO -f nc -setunit,"Sv" -mulc,1.025e-9 -selcode,101 $infile atl_moc.$infile
ncrename -d depth_2,depth -v depth_2,depth atl_moc.$infile
$BINDIR/plotsec_ncl --rstring=atl --code=101 --min=-24 --max=24 --inc=3 --pal=BlueWhiteOrangeRed atl_moc.$infile

$CDO -f nc -setunit,"Sv" -mulc,1.025e-9 -selcode,102 $infile indopacific_moc.$infile
ncrename -d depth_2,depth -v depth_2,depth indopacific_moc.$infile
$BINDIR/plotsec_ncl --rstring=indopac --code=102 --min=-24 --max=24 --inc=3 --pal=BlueWhiteOrangeRed indopacific_moc.$infile

cd -

mv $TMP_DIR/*.$outfile .

rm -rf $TMP_DIR
