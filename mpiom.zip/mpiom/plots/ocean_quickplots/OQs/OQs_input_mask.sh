#! /bin/sh

FX=$POOL/$GRID/$GRID${LEV}_fx.nc
MAP=$POOL/$GRID/${GRID}_map.nc
CDO=${CDO:-cdo -s}

make -j 4 -f - << EOF

$(basename $0): mask_3d.nc mask_antarc.nc mask_arc.nc mask_glo.nc mask_atl.nc mask_atl_arc.nc mask_indopacific.nc FORCE

mask_3d.nc: ${FX}
	${CDO} div -selvar,ddpo ${FX} -selvar,ddpo ${FX} mask_3d.nc 

mask_antarc.nc: ${MAP}
	${CDO} setctomiss,0 -eqc,6 -selcode,511 ${MAP} mask_antarc.nc

mask_arc.nc: ${MAP}
	${CDO} setctomiss,0 -lec,4 -selcode,511 ${MAP} mask_arc.nc

mask_glo.nc: ${MAP}
	${CDO} setctomiss,0 -lec,10 -selcode,511 ${MAP} mask_glo.nc

mask_atl.nc: ${MAP}
	${CDO} setctomiss,0 -add -eqc,4 -selcode,511 ${MAP} -eqc,5 -selcode,511 ${MAP} mask_atl.nc

mask_atl_arc.nc: ${MAP}
	${CDO} setctomiss,0 -lec,5 -selcode,511 ${MAP} mask_atl_arc.nc

mask_indopacific.nc: ${MAP}
	${CDO} setctomiss,0 -add -eqc,7 -selcode,511 ${MAP} -eqc,8 -selcode,511 ${MAP} mask_indopacific.nc

FORCE:

EOF
