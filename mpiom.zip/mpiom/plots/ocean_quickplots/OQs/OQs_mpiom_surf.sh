#! /usr/bin/env bash
set -e

set -x # DEBUG

PROGRAM=$(basename $0)

TMP_DIR=${PROGRAM}_$Y1-$Y2
[ -e $TMP_DIR ] && rm -rf $TMP_DIR
mkdir -p $TMP_DIR
cd $TMP_DIR

ref_SAL=$POOL/$GRID/$GRID${LEV}_INISAL_PHC 
ref_TEM=$POOL/$GRID/$GRID${LEV}_INITEM_PHC 

CATFILE=surfdata.nc
CATFILE2=surfdata39.nc

CODE='1,12,16,27,109,165,170'
CODE2='13,15,141,183,276'

for YEAR in $(seq $Y1 $CHUNK $Y2) 
do
    INFILE=$(printf $DATADIR/${EXPID}_mpiom_data_2d_mm_%04.0f0101_%04.0f1231.nc $YEAR $((YEAR + CHUNK - 1)))

    if [ -e $INFILE ]
    then
        $CDO cat -timmean -selcode,$CODE $INFILE $CATFILE &
        $CDO cat -selmon,3,9 -selcode,$CODE2 $INFILE $CATFILE2 &
        wait
    else
        echo Warning ! $INFILE is missing, skipping to next file ...
    fi
done

$CDO sinfo $CATFILE # DEBUG
$CDO sinfo $CATFILE2 # DEBUG
inbase=$(printf ${EXPID}_mpiom_surf_%04.0f0101_%04.0f1231 $Y1 $Y2)
infile=$inbase.nc
outfile=$inbase.pdf
inbase2=$(printf ${EXPID}_mpiom_surf39_%04.0f0101_%04.0f1231 $Y1 $Y2)
infile2=$inbase2.nc
outfile2=$inbase2.pdf
$CDO timmean $CATFILE $infile &
$CDO ymonmean $CATFILE2 $infile2 &
wait
rm -f $CATFILE $CATFILE2

$BINDIR/plot2d_ncl --lstring=msftbarot --cstring=barotropic_streamfunction --rstring=[Sv] --code=27 --min=-100 --max=250 --inc=10 --scal=1.025e-9 --type=0 $infile
mv $outfile psi.$outfile

$BINDIR/plot2d_ncl  --lstring=zos --code=1 --min=-2 --max=2 --inc=0.2 --pal=BlueWhiteOrangeRed $infile
mv $outfile zos.$outfile

$BINDIR/plot2d_ncl  --lstring=t20d --code=109 --min=0 --max=300 --inc=30 --pal=WhiteBlueGreenYellowRed $infile
mv $outfile t20d.$outfile

$BINDIR/plot2d_ncl  --lstring=hfsd --code=170 --min=-150 --max=150 --inc=15 --pal=BlueWhiteOrangeRed $infile
mv $outfile hfsd.$outfile

$BINDIR/plot2d_ncl  --lstring=wfonocor --code=165 --min=-1e-4 --max=1e-4 --inc=1e-5 --pal=BlueWhiteOrangeRed $infile
mv $outfile wfonocor.$outfile

$BINDIR/plot2d_ncl  --lstring=tos --code=12 --min=-2 --max=30 --inc=2 --pal=GMT_haxby $infile
mv $outfile tos.$outfile

#### compute anomalies to Levitus ####
$CDO -f nc sub -selcode,12 $infile -selcode,2 -sellevidx,1 $ref_TEM ano-tos.$infile
$BINDIR/plot2d_ncl  --lstring=ano-tos  --code=12 --min=-5 --max=5 --inc=0.5 --pal=BlueWhiteOrangeRed ano-tos.$infile

$BINDIR/plot2d_ncl  --lstring=sos  --code=16 --min=32 --max=37 --inc=0.25 --pal=WhiteBlueGreenYellowRed $infile
mv $outfile sos.$outfile

#### compute anomalies to Levitus ####
$CDO -f nc sub -selcode,16 $infile -selcode,5 -sellevidx,1 $ref_SAL ano-sos.$infile.nc
$BINDIR/plot2d_ncl --lstring=ano-sos --code=16 --min=-2 --max=2 --inc=0.2 --pal=BlueWhiteOrangeRed ano-sos.$infile

#### Seasonal plots ####

$BINDIR/plot2d_ncl --lstring=sivol --lev=1 --code=13 --min=0 --max=6 --inc=0.5 --pal=WhiteBlueGreenYellowRed --proj=NPS $infile2
mv $outfile2 sivol-NH.$outfile2

$BINDIR/plot2d_ncl --lstring=sivol --lev=1 --code=13 --min=0 --max=6 --inc=0.5 --pal=WhiteBlueGreenYellowRed --proj=SPS $infile2
mv $outfile2 sivol-SH.$outfile2

$BINDIR/plot2d_ncl --lstring=siconc --lev=1 --code=15 --min=0 --max=1 --inc=0.05 --pal=WhiteBlueGreenYellowRed --proj=NPS $infile2
mv $outfile2 siconc-NH.$outfile2

$BINDIR/plot2d_ncl --lstring=siconc --lev=1 --code=15 --min=0 --max=1 --inc=0.05 --pal=WhiteBlueGreenYellowRed --proj=SPS $infile2
mv $outfile2 siconc-SH.$outfile2

$BINDIR/plot2d_ncl --lstring=sicsno --lev=1 --code=141 --min=0 --max=1 --inc=0.05 --pal=WhiteBlueGreenYellowRed --proj=NPS $infile2
mv $outfile2 sicsno-NH.$outfile2

$BINDIR/plot2d_ncl --lstring=sicsno --lev=1 --code=141 --min=0 --max=1 --inc=0.05 --pal=WhiteBlueGreenYellowRed --proj=SPS $infile2
mv $outfile2 sicsno-SH.$outfile2

$CDO showcode -selcode,276 $infile2 > /dev/null 2>&1 && # Optional
$BINDIR/plot2d_ncl --lstring=mlotst --lev=1 --code=276 --min=0 --max=2500 --inc=125 --pal=WhiteBlueGreenYellowRed $infile2
mv $outfile2 mlotst.$outfile2

$CDO showcode -selcode,183 $infile2 > /dev/null 2>&1 && # Optional
$BINDIR/plot2d_ncl --lstring=zmld --lev=1 --code=183 --min=0 --max=5000 --inc=250 --pal=WhiteBlueGreenYellowRed $infile2
mv $outfile2 zmld.$outfile2

cd -

mv $TMP_DIR/*.$outfile $TMP_DIR/*.$outfile2 .

rm -rf $TMP_DIR
