#! /usr/bin/env bash
set -e

set -x # DEBUG

PROGRAM=$(basename $0)

TMP_DIR=${PROGRAM}_$Y1-$Y2
[ -e $TMP_DIR ] && rm -rf $TMP_DIR
mkdir -p $TMP_DIR
cd $TMP_DIR

$BINDIR/OQs_input_mask.sh $GRID $LEV

ref_SAL=$POOL/$GRID/$GRID${LEV}_INISAL_PHC 
ref_TEM=$POOL/$GRID/$GRID${LEV}_INITEM_PHC 

CATFILE=subsurfdata.nc

CODE='2,5'

for YEAR in $(seq $Y1 $CHUNK $Y2) 
do
    INFILE=$(printf $DATADIR/${EXPID}_mpiom_data_3d_mm_%04.0f0101_%04.0f1231.nc $YEAR $((YEAR + CHUNK - 1)))

    if [ -e $INFILE ]
    then
        $CDO cat -timmean -selcode,$CODE $INFILE $CATFILE
    else
        echo Warning ! $INFILE is missing, skipping to next file ...
    fi
done

$CDO sinfo $CATFILE # DEBUG
inbase=$(printf ${EXPID}_mpiom_subsurf_%04.0f0101_%04.0f1231 $Y1 $Y2)
infile=$inbase.nc
outfile=$inbase.pdf
$CDO timmean $CATFILE $infile

for basin in glo atl_arc indopacific 
do
    $CDO -f nc -zonmean -remapnn,r720x360 -selcode,2 -mul $infile mask_$basin.nc ${basin}_thetao.$infile
    $BINDIR/plotsec_ncl --rstring=$basin --code=2 --min=-2 --max=30 --inc=2 --pal=GMT_haxby ${basin}_thetao.$infile

    $CDO -f nc -zonmean -remapnn,r720x360 -sub -selcode,2 -mul $infile mask_$basin.nc -selcode,2 $ref_TEM ${basin}_ano-thetao.$infile
    $BINDIR/plotsec_ncl --rstring=$basin --code=2 --min=-5 --max=5 --inc=0.5 --pal=BlueWhiteOrangeRed ${basin}_ano-thetao.$infile

    $CDO -f nc -zonmean -remapnn,r720x360 -selcode,5 -mul $infile mask_$basin.nc ${basin}_so.$infile
    $BINDIR/plotsec_ncl --rstring=$basin --code=5 --min=32 --max=37 --inc=0.25 --pal=GMT_haxby ${basin}_so.$infile

    $CDO -f nc -zonmean -remapnn,r720x360 -sub -selcode,5 -mul $infile mask_$basin.nc -selcode,5 $ref_SAL ${basin}_ano-so.$infile
    $BINDIR/plotsec_ncl --rstring=$basin --code=5 --min=-1 --max=1 --inc=0.1 --pal=BlueWhiteOrangeRed ${basin}_ano-so.$infile
done

cd -

mv $TMP_DIR/*.$outfile .

rm -rf $TMP_DIR
