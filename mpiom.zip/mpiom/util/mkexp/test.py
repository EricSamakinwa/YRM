import os
import re
import sys
import unittest

from os.path import join



def align(string):
    return re.sub(r'\n\s*', '\n', string.lstrip())

def script(string):
    return align("""
        set -e
        unset CDPATH
        cd test
        PATH=..:$PATH
    """) + align(string)

def output(command):
    (ignore, stream) = os.popen4(command)
    return stream.read()

def readfile(filename):
    stream = open(filename)
    return stream.read()

def writefile(filename, string):
    stream = open(filename, 'w')
    stream.write(string)

def writeconfig(exp_id, string):
    writefile(join("test", exp_id+".config"), string)

def writetemplate(exp_id, job_id, string):
    writefile(join("test", exp_id+"."+job_id+".tmpl"), string)



class MkexpTestCase(unittest.TestCase):

    script_clean = script("""
        rm -rf experiments
        rm -f test_*
    """)

    script_run = script("""
        mkexp test0001.config
    """)

    def setUp(self):
        os.system(self.script_clean)

    @classmethod
    def tearDownClass(cls):
        os.system(cls.script_clean)



class RunningTestCase(MkexpTestCase):

    def test_missing_config_file(self):
        result = output('./mkexp')
        self.assertIn('error: too few arguments', result)

    def test_clean_run(self):
        expected = align("""
            Hey: cannot find experiment config for '', using default only
            Script directory: 'experiments/test0001'
            Data directory: 'experiments/test0001'
        """)
        result = output(self.script_run)
        self.assertMultiLineEqual(expected, result)

    def test_backup_run(self):
        expected = "Hey: script directory already exists, "+\
                   "moving existing scripts to backup"
        ignore = output(self.script_run)
        result = output(self.script_run)
        self.assertIn(expected, result)

class CommandLineTestCase(MkexpTestCase):

    def test_pass_section_variables(self):
        script_section = script("""
            mkexp test0001.config \
                namelists.namelist..echam.runctl.dt_start=2345,01,23,12,34,56 \
                namelists.namelist..echam.runctl.some_file=abcdefgh.ijk
        """)
        expecteds = ["dt_start = 2345, 1, 23, 12, 34, 56",
                     "some_file = 'abcdefgh.ijk'"]
        ignore = output(script_section)
        result = readfile('test/experiments/test0001/test0001.run')
        for expected in expecteds:
            self.assertIn(expected, result)

    def test_pass_new_job(self):
        output(script("mkexp test0001.config jobs.dummy...extends=run"))
        readfile('test/experiments/test0001/test0001.dummy')
        # Should exist, otherwise exception is thrown

    def test_options(self):
        script_option = script("""
            mkexp test0001.config EXP_OPTIONS=option1
        """)
        expected = "default_output = .false."
        ignore = output(script_option)
        result = readfile('test/experiments/test0001/test0001.run')
        self.assertIn(expected, result)

class ContentTestCase(MkexpTestCase):

    def test_job_override(self):
        exp_id = "test_job_override"
        writeconfig(exp_id, """
            EXP_TYPE =
            [jobs]
              key1 = global
              key2 = global
              [[job1]]
                key1 = local
        """)
        writetemplate(exp_id, "job1", """
            key1 = %{JOB.key1}
            key2 = %{JOB.key2}
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+".job1"))
        self.assertIn("key1 = local", result)
        self.assertIn("key2 = global", result)

    def test_var_statement(self):
        exp_id = "test_var_statement"
        job_id = "job"
        writeconfig(exp_id, """
            EXP_TYPE = 
            GLOBAL1 = 123$${VAR1}456
            GLOBAL2 = $${VAR2}$${VAR3}
            GLOBAL3 = 1, $${VAR2}, 3
            GLOBAL${FOUR} = 4
            [namelists]
              [[namelist]]
                [[[group]]]
                  key = abc$${var}def
            [jobs]
              [["""+job_id+"""]]
                .var_format = <<<%s>>>
        """)
        writetemplate(exp_id, job_id, """
            GLOBAL1=%{GLOBAL1}
            GLOBAL2=%{GLOBAL2}
            GLOBAL3='%{GLOBAL3|join(" ")}'
            GLOBAL4=%{context("GLOBAL<<<FOUR>>>")}
            %{NAMELIST}
        """)
        expected = align("""
            GLOBAL1=123<<<VAR1>>>456
            GLOBAL2=<<<VAR2>>><<<VAR3>>>
            GLOBAL3='1 <<<VAR2>>> 3'
            GLOBAL4=4
            &group
                key = 'abc<<<var>>>def'
            /
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_var_list_in_context(self):
        exp_id = "test_var_list_in_context"
        job_id = "job"
        writeconfig(exp_id, """
            EXP_TYPE =
            VAR1 = value1
            GLOBAL1 = $${VAR1} # Initialized
            GLOBAL2 = $${VAR2} # Uninitialized
            GLOBAL3 = $${VAR1} # Used twice, may only be listed once
            GLOBAL${FOUR} = 4  # (Uninitialized) Variable in key
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            #% for var in VARIABLES_:
            %{var}=%{context(var)}
            #% endfor
        """)
        expected = align("""
            FOUR=
            VAR1=value1
            VAR2=
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_namelist_comments(self):
        exp_id = "test_namelist_comments"
        job_id = "job"
        writeconfig(exp_id, """
            EXP_TYPE =
            [namelists]
              [[namelist]]
                # var_1b = 84
                [[[group_1]]]
                  # Comment for var 1a
                  var_1a = 42 # Inline comment for var 1a
                # var_2a = 10.5
                [[[group_2]]]
                  # Comment for var 2b
                  var_2b = 21 # Inline comment for var 2b
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            %{NAMELIST}
        """)
        expected = align("""
            &group_1
                ! Comment for var 1a
                var_1a = 42 ! Inline comment for var 1a
                ! var_1b = 84
            /
            &group_2
                ! Comment for var 2b
                var_2b = 21 ! Inline comment for var 2b
                ! var_2a = 10.5
            /
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_var_in_namelist(self):
        exp_id = "test_var_in_namelist"
        job_id = "job"
        writeconfig(exp_id, """
            EXP_TYPE =
            [namelists]
              [[namelist]]
                [[[group]]]
                  var_1 = raw($$value_1)
                  var_2 = raw($${value_2})
                  var_3 = a, raw($$value_3), b
                  var_4 = a$$value_4
                  var_5 = $${value_5}b
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            %{NAMELIST}
        """)
        expected = align("""
            &group
                var_1 = $value_1
                var_2 = ${value_2}
                var_3 = 'a', $value_3, 'b'
                var_4 = 'a$value_4'
                var_5 = '${value_5}b'
            /
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_split_date(self):
        exp_id = 'test_split_date'
        job_id = 'job'
        writeconfig(exp_id, """
            EXP_TYPE =
            DATE_ISO = 1234-05-06
            DATE_RAW = 12340506
            DATE_LIST_ISO = split_date($DATE_ISO)
            DATE_LIST_RAW = split_date($DATE_RAW)
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            %{DATE_LIST_ISO|join(',')}
            %{DATE_LIST_RAW|join(',')}
        """)
        expected = align("""
            1234,5,6,0,0,0
            1234,05,06,0,0,0
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_add_years(self):
        exp_id = 'test_add_years'
        job_id = 'job'
        writeconfig(exp_id, """
            EXP_TYPE =
            DATE = 1234-05-06
            NEXT_DATE = 'add_years($DATE, 1)'
            PREVIOUS_DATE = 'add_years($DATE, -1)'
            NEGATIVE_DATE = 'add_years($DATE, -2000)'
            LONGYEAR_DATE = 'add_years($DATE, 10000)'
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            %{NEXT_DATE}
            %{PREVIOUS_DATE}
            %{NEGATIVE_DATE}
            %{LONGYEAR_DATE}
        """)
        expected = align("""
            1235-05-06
            1233-05-06
            -0766-05-06
            11234-05-06
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

    def test_add_days(self):
        exp_id = 'test_add_days'
        job_id = 'job'
        writeconfig(exp_id, """
            EXP_TYPE =
            DATE = 1234-05-06
            NEXT_DATE = 'add_days($DATE, 1)'
            PREVIOUS_DATE = 'add_days($DATE, -1)'
            NEGATIVE_DATE = 'add_days($DATE, -2000)'
            LONGYEAR_DATE = 'add_days($DATE, 10000)'
            LATE_DATE = 9999-12-31
            LATER_DATE = 'add_days($LATE_DATE, 1)'
            EARLY_DATE = 0000-01-01
            EARLIER_DATE = 'add_days($EARLY_DATE, -1)'
            [jobs]
              [["""+job_id+"""]]
        """)
        writetemplate(exp_id, job_id, """
            %{NEXT_DATE}
            %{PREVIOUS_DATE}
            %{NEGATIVE_DATE}
            %{LONGYEAR_DATE}
            %{LATER_DATE}
            %{EARLIER_DATE}
        """)
        expected = align("""
            1234-05-07
            1234-05-05
            1228-11-13
            1261-09-21
            10000-01-01
            -0001-12-31
        """)
        ignore = output(script("mkexp "+exp_id+".config"))
        result = readfile(join("test", "experiments", exp_id, exp_id+"."+job_id))
        result = align(result)
        self.assertMultiLineEqual(expected, result)

if __name__ == '__main__':
    unittest.main()
